Tim McVicker
SDE1, Flex and Bison

Pledge:
On my honor I have neither given nor received aid on this
exam.

prolog1.c contains the main function to be used during execution
prolog1.in is used by flex to return tokens based on input characters
prolog1.y contains the grammar for the program as well as the print function
prolog1.log contains ten examples of execution
